-- Crea il database
CREATE DATABASE IF NOT EXISTS strumenti_musicali;
USE strumenti_musicali;

-- Tabella utenti
CREATE TABLE utenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cognome VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    indirizzo VARCHAR(255),
    citta VARCHAR(100),
    cap VARCHAR(10),
    provincia VARCHAR(50),
    paese VARCHAR(100) DEFAULT 'Italia',
    telefono VARCHAR(20),
    ruolo ENUM('cliente', 'admin') DEFAULT 'cliente',
    data_registrazione DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabella categorie
CREATE TABLE categorie (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descrizione TEXT,
    immagine VARCHAR(255)
);

-- Tabella strumenti
CREATE TABLE strumenti (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    marca VARCHAR(100),
    modello VARCHAR(100),
    descrizione TEXT,
    prezzo DECIMAL(10,2) NOT NULL,
    quantita INT DEFAULT 0,
    immagine VARCHAR(255),
    disponibilita BOOLEAN DEFAULT TRUE,
    id_categoria INT,
    data_aggiunta DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_categoria) REFERENCES categorie(id)
);

-- Tabella ordini
CREATE TABLE ordini (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_utente INT,
    data_ordine DATETIME DEFAULT CURRENT_TIMESTAMP,
    totale DECIMAL(10,2),
    stato ENUM('in elaborazione', 'spedito', 'consegnato', 'annullato') DEFAULT 'in elaborazione',
    indirizzo_spedizione VARCHAR(255),
    metodo_pagamento ENUM('carta', 'paypal', 'bonifico') DEFAULT 'carta',
    note TEXT,
    FOREIGN KEY (id_utente) REFERENCES utenti(id)
);

-- Tabella dettagli_ordini
CREATE TABLE dettagli_ordini (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_ordine INT,
    id_strumento INT,
    quantita INT,
    prezzo_unitario DECIMAL(10,2),
    FOREIGN KEY (id_ordine) REFERENCES ordini(id),
    FOREIGN KEY (id_strumento) REFERENCES strumenti(id)
);

-- Tabella carrello
CREATE TABLE carrello (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_utente INT,
    id_strumento INT,
    quantita INT DEFAULT 1,
    aggiunto_il DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_utente) REFERENCES utenti(id),
    FOREIGN KEY (id_strumento) REFERENCES strumenti(id)
);
