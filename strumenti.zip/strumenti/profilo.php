<?php
session_start();

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "strumenti_musicali";

$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

// Verifica se l'utente è loggato
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: login.php");
    exit();
}

// Ottieni le informazioni dell'utente loggato
$id_utente = $_SESSION['id_utente'];
$stmt = $conn->prepare("SELECT nome, cognome, email, indirizzo, citta FROM utenti WHERE id = ?");
$stmt->bind_param("i", $id_utente);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Profilo - AudioCore</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f3f3f3;
            display: flex;
            flex-direction: column;
            align-items: center;
            height: 100vh;
            justify-content: center;
        }

        .profile-box {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            width: 400px;
            text-align: left;
        }

        .profile-box h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .profile-box p {
            margin: 8px 0;
            font-size: 1.1em;
        }

        .home-button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #1c87c9;
            color: white;
            border: none;
            border-radius: 5px;
            font-size: 1em;
            cursor: pointer;
        }

        .home-button:hover {
            background-color: #155d8b;
        }
    </style>
</head>
<body>

<div class="profile-box">
    <h2>Profilo di <?= htmlspecialchars($user['nome'] . ' ' . $user['cognome']); ?></h2>
    <p><strong>Email:</strong> <?= htmlspecialchars($user['email']); ?></p>
    <p><strong>Indirizzo:</strong> <?= htmlspecialchars($user['indirizzo']); ?></p>
    <p><strong>Città:</strong> <?= htmlspecialchars($user['citta']); ?></p>
</div>

<!-- Pulsante per tornare alla home -->
<form action="home.php" method="get">
    <button type="submit" class="home-button">Torna alla homepage</button>
</form>

</body>
</html>
