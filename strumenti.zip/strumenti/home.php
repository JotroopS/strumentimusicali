<?php
session_start();

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "strumenti_musicali";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

$nome = '';
$cognome = '';

if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true && isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $sql = "SELECT nome, cognome FROM utenti WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($nome, $cognome);
    $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AudioCore - Home</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f9f9f9;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            overflow-x: hidden;
        }

        header {
            background-color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .logo {
            font-size: 1.8em;
            font-weight: bold;
            color: #111;
        }

        .nav-icons {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-icons img {
            width: 24px;
            height: 24px;
            cursor: pointer;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #fff;
            min-width: 160px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .dropdown-content a, .dropdown-content p {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            margin: 0;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .search-bar {
            margin: 20px auto;
            max-width: 600px;
            display: flex;
            gap: 10px;
            padding: 0 20px;
        }

        .search-bar input {
            flex: 1;
            padding: 12px;
            font-size: 1em;
            border-radius: 30px;
            border: 1px solid #ccc;
        }

        .slider {
            position: relative;
            width: 100%;
            max-width: 600px;
            height: 400px;
            margin: auto;
            overflow: hidden;
        }

        .slider-images {
            display: flex;
            width: calc(600px * 6);
            transition: transform 0.8s ease-in-out;
        }

        .slider-images img {
            width: 600px;
            height: 400px;
            object-fit: contain;
            flex-shrink: 0;
        }

        .benefits {
            display: flex;
            justify-content: center;
            gap: 30px;
            padding: 30px 20px;
            background-color: #fff;
            text-align: center;
        }

        .benefit {
            max-width: 180px;
        }

        .benefit-icon {
            font-size: 2em;
            margin-bottom: 10px;
            color: #1c87c9;
        }

        footer {
            background-color: #222;
            color: #fff;
            text-align: center;
            padding: 15px;
            margin-top: auto;
        }

        .user-info {
            margin-left: 10px;
            font-size: 14px;
            color: #555;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">AudioCore</div>
    <div class="nav-icons">
        <?php if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true): ?>
            <div class="dropdown">
                <img src="https://img.icons8.com/ios-filled/50/user.png" alt="User">
                <div class="dropdown-content">
                    <p class="user-info"><?php echo htmlspecialchars($nome) . ' ' . htmlspecialchars($cognome); ?></p>
                    <a href="profilo.php">Profilo</a>
                    <a href="#" onclick="confermaLogout(event)">Logout</a>
                </div>
            </div>
        <?php else: ?>
            <a href="login.php">
                <img src="https://img.icons8.com/ios-filled/50/user.png" alt="User">
            </a>
        <?php endif; ?>
        <a href="#">
            <img src="https://img.icons8.com/ios-filled/50/like.png" alt="Cuore">
        </a>
        <a href="#">
            <img src="https://img.icons8.com/ios-filled/50/shopping-cart.png" alt="Carrello">
        </a>
    </div>
</header>

<div class="search-bar">
    <input type="text" placeholder="Cerca strumenti musicali...">
</div>

<div class="slider">
    <div class="slider-images" id="slider-images">
        <img src="chitarra.jpg" alt="Chitarra">
        <img src="batteria.jpg" alt="Batteria">
        <img src="basso.jpg" alt="Basso">
        <img src="chitarra1.jpg" alt="Chitarra1">
        <img src="microfono.jpg" alt="Microfono">
        <img src="pianoforte.jpg" alt="Pianoforte">
    </div>
</div>

<section class="benefits">
    <div class="benefit">
        <div class="benefit-icon">🔁</div>
        <h4>30 giorni di prova</h4>
        <p>Garanzia soddisfatti o rimborsati</p>
    </div>
    <div class="benefit">
        <div class="benefit-icon">🛡️</div>
        <h4>3 anni di garanzia</h4>
        <p>Su tutti i nostri prodotti</p>
    </div>
    <div class="benefit">
        <div class="benefit-icon">📦</div>
        <h4>Spedizione gratuita</h4>
        <p>Per ordini sopra 99€</p>
    </div>
</section>

<footer>
    &copy; 2025 AudioCore. Tutti i diritti riservati.
</footer>

<script>
    let currentIndex = 0;
    const images = document.querySelectorAll('.slider-images img');
    const totalImages = images.length;
    const sliderImages = document.getElementById('slider-images');

    setInterval(() => {
        currentIndex = (currentIndex + 1) % totalImages;
        sliderImages.style.transform = `translateX(-${currentIndex * 600}px)`;
    }, 3000);

    function confermaLogout(event) {
        event.preventDefault();
        if (confirm("Sei sicuro di voler uscire?")) {
            window.location.href = "logout.php";
        }
    }
</script>

</body>
</html>
