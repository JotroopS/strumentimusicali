<?php
session_start();

// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Strumenti_musicali";

$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AudioCore - Home</title>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background-color: #f9f9f9;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        header {
            background-color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .logo {
            font-size: 1.8em;
            font-weight: bold;
            color: #111;
        }

        .nav-icons {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .nav-icons img {
            width: 24px;
            height: 24px;
            cursor: pointer;
        }

        .search-bar {
            margin: 20px auto;
            max-width: 600px;
            display: flex;
            gap: 10px;
            padding: 0 20px;
        }

        .search-bar input {
            flex: 1;
            padding: 12px;
            font-size: 1em;
            border-radius: 30px;
            border: 1px solid #ccc;
        }

        .hero {
            position: relative;
            max-width: 1000px;
            margin: 20px auto;
            height: 350px;
            overflow: hidden;
            border-radius: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            background-color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero img {
            max-width: 100%;
            max-height: 100%;
            object-fit: scale-down;
            display: block;
        }

        .hero-text {
            position: absolute;
            top: 20px;
            left: 20px;
            color: white;
            background-color: rgba(0, 0, 0, 0.6);
            padding: 15px;
            border-radius: 10px;
        }

        .benefits {
            display: flex;
            justify-content: center;
            gap: 30px;
            padding: 30px 20px;
            background-color: #fff;
            text-align: center;
        }

        .benefit {
            max-width: 180px;
        }

        .benefit-icon {
            font-size: 2em;
            margin-bottom: 10px;
            color: #1c87c9;
        }

        footer {
            background-color: #222;
            color: #fff;
            text-align: center;
            padding: 15px;
            margin-top: auto;
        }
    </style>
</head>
<body>

<header>
    <div class="logo">AudioCore</div>
    <div class="nav-icons">
    <a href="login.php">
    <img src="https://img.icons8.com/ios-filled/50/user.png" alt="User">
</a>
        <img src="https://img.icons8.com/ios-glyphs/30/like--v1.png" alt="Favorites">
        <img src="https://img.icons8.com/ios-glyphs/30/shopping-cart.png" alt="Cart">
    </div>
</header>

<div class="search-bar">
    <input type="text" placeholder="Cerca strumenti musicali...">
</div>

<div class="hero">
    <img src="chitarra.jpg" alt="Promo Chitarra">
</div>

<section class="benefits">
    <div class="benefit">
        <div class="benefit-icon">🔁</div>
        <h4>30 giorni di prova</h4>
        <p>Garanzia soddisfatti o rimborsati</p>
    </div>
    <div class="benefit">
        <div class="benefit-icon">🛡️</div>
        <h4>3 anni di garanzia</h4>
        <p>Su tutti i nostri prodotti</p>
    </div>
    <div class="benefit">
        <div class="benefit-icon">📦</div>
        <h4>Spedizione gratuita</h4>
        <p>Per ordini sopra 99€</p>
    </div>
</section>

<footer>
    &copy; 2025 AudioCore. Tutti i diritti riservati.
</footer>

</body>
</html>