<?php
// Connessione al database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Strumenti_musicali";

$conn = new mysqli($servername, $username, $password, $dbname);

// Controllo della connessione
if ($conn->connect_error) {
    die("Connessione fallita: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Verifica se l'email esiste già
    $sql = "SELECT * FROM utenti WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $error = "L'email è già registrata.";
    } else {
        // Hashing della password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Inserimento nel database
        $sql = "INSERT INTO utenti (nome, email, password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $username, $email, $hashed_password);

        if ($stmt->execute()) {
            $success = "Registrazione completata! Ora puoi effettuare il login.";
        } else {
            $error = "Errore nella registrazione. Riprova più tardi.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Registrazione - AudioCore</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f3f3f3;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .register-box {
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            width: 300px;
        }

        .register-box h2 {
            margin-bottom: 20px;
            text-align: center;
        }

        .register-box input {
            width: 100%;
            padding: 10px;
            margin: 8px 0;
            border: 1px solid #ccc;
            border-radius: 6px;
        }

        .register-box button {
            width: 100%;
            padding: 10px;
            background: #28a745;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
        }

        .register-box .error {
            color: red;
            font-size: 0.9em;
            text-align: center;
            margin-bottom: 10px;
        }

        .register-box .success {
            color: green;
            font-size: 0.9em;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
<div class="register-box">
    <h2>Registrazione</h2>
    <?php if (isset($error)): ?>
        <div class="error"><?= $error ?></div>
    <?php elseif (isset($success)): ?>
        <div class="success"><?= $success ?></div>
    <?php endif; ?>
    <form method="post">
        <input type="text" name="username" placeholder="Username" required />
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Registrati</button>
        <a href="home.php">
            <button type="button" style="margin-top: 10px; background-color: #dc3545;">Indietro</button>
        </a>
    </form>
</div>
</body>
</html>
